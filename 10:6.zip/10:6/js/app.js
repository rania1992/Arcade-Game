
var Enemy = function(x,y,speed) {
    this.x = x;
    this.y = y + 55 ;
    this.speed = speed;
    this.step = 101;
    this.sprite = 'images/enemy-bug.png';
    this.boundary = this.step * 5;
    this.resetpos = -this.step ;
};
const bug1 = new Enemy(-101,0,200);
const bug2 = new Enemy(500,50,350);
const bug3 = new Enemy((-101*2.5),83,250);
const bug4 = new Enemy(101,166,400);
const bug5 = new Enemy(-110,115,300);
const allEnemies = [];
allEnemies.push(bug1,bug2,bug3,bug4,bug5);

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {

    if (this.x < this.boundary)
    {
        this.x += this.speed * dt;

    }
    else {
        this.x = this.resetpos;
    }
    

{
if (player.x < this.x + 60 &&
    player.x + 37 > this.x &&
    player.y < this.y + 25 &&
    30 + player.y > this.y) 
    {
    player.x = 200;
    player.y = 400;
    } 
}

};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};


class main {

    constructor() {
        this.sprite = 'images/char-cat-girl.png';
        this.horizantal_step = 101;
        this.vertical_step = 83;
        this.positionx = 101 * 2;
        this.positiony = (83 * 5) -15 ;
        this.x = this.positionx;
        this.y = this.positiony;
         
    }

    render() {
        ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
    }
    handleInput(input){

		switch(input){
			case 'left':{
				this.x -= this.horizantal_step;
				break;
			}
			case 'right':{
				this.x += this.horizantal_step;
				break;
			}
			case 'up':{
				this.y -= this.vertical_step;
				break;
			}
			case 'down':{
				this.y += this.vertical_step;
				break;
			}
        }
        
        if(this.x < 0)
        {
             this.x += this.horizantal_step ;
            }
        if(this.x > this.horizantal_step * 4)
         {
            this.x -= this.horizantal_step ;
        }
        if(this.y < -this.vertical_step)
        {
             this.y += this.vertical_step;
        }
        if(this.y > this.vertical_step * 5) {
        this.y -= this.vertical_step ;
    }
       if(this.y < 0) {
           this.x = this.positionx;
           this.y = this.positiony;
           
       }        

}}

   
const player = new main();


document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    
    player.handleInput(allowedKeys[e.keyCode]);



});
